define({
  tabs: [],
  stack: []
});